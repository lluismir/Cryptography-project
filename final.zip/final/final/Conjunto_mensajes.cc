#include <iostream>
#include "Conjunto_mensajes.hh"

using namespace std;

Conjunto_mensajes::Conjunto_mensajes() {
    
}


Conjunto_mensajes::~Conjunto_mensajes() {
    
}


void Conjunto_mensajes::nuevo_mensaje(string& idm, string& mensaje) {
    cjt_men.insert(make_pair(idm,mensaje));
}

void Conjunto_mensajes::anadir_mensaje_inicial(int& M) {
    string mensaje,idm, trash;
    
    for(int i = 0; i < M; ++i) {
        cin >> idm;
        getline(cin,trash);
        getline(cin,mensaje);
        nuevo_mensaje(idm,mensaje);
    }
}

void Conjunto_mensajes::borrar_mensaje(string& idm) {
    map<string,string>::iterator it = cjt_men.find(idm);
    cjt_men.erase(it);
}

int Conjunto_mensajes::mensaje_valido(string& mensaje, int& n) const{
    int tamano = int(mensaje.size());
    int bloque = n*n;
    if((tamano%bloque)== 0) return 0;
    else return -1;
}

void Conjunto_mensajes::listar_mensajes() const {
    map<string,string>::const_iterator it = cjt_men.begin();
    while(it != cjt_men.end()) {
        cout << (*it).first << endl;
        cout << '"' << (*it).second << '"' << endl;
        ++it;
    }
}

int Conjunto_mensajes::consultar_numero_mensajes() const {
    return int(cjt_men.size());
}

string Conjunto_mensajes::consultar_mensaje(string &idm) const {
    map<string,string>::const_iterator it = cjt_men.find(idm);
    return it->second;
}


int Conjunto_mensajes::existe_mensaje(string& idm) const {
    map<string,string>::const_iterator it = cjt_men.find(idm);
    if(it != cjt_men.end()) return 0;
    else return -1;
}


