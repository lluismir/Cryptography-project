#include <iostream>
#include "Rejilla.hh"

using namespace std;

Rejilla::Rejilla(){
}

Rejilla::~Rejilla(){
}

Rejilla::Rejilla(int n, int k, int idr) {
    this -> n = n;
    this -> k = k;
    this -> idr = idr;
}

int Rejilla::consultar_n() const {
    return n;
}

int Rejilla::consultar_k() const{
    return k;
}

bool Rejilla::comp(const Hueco& h1, const Hueco& h2){
    if(h1.i != h2.i) return h1.i < h2.i;
    return h1.j < h2.j;
}

void Rejilla::codificar_rejilla(const string&  mensaje) const{
    int tamano_bloque = n*n;
    int nbloques = int(mensaje.size() / tamano_bloque);
    if(int(mensaje.size() % tamano_bloque) != 0)  ++nbloques;
    vector<vector<char> > mat(n,vector<char>(n,' '));

    cout << '"';
    for(int i = 0; i < nbloques; ++i) {
        int ori = 0+i*tamano_bloque;
        int g1 = k+i*tamano_bloque;
        int g2 = 2*k+i*tamano_bloque;
        int g3 = 3*k+i*tamano_bloque;
        for(int i = 0; i < n; ++i) {
            for(int j = 0; j < n; ++j) {
                mat[i][j] = ' ';
            }
        }
        for(int j = 0; j < k; ++j){
            if(ori < mensaje.size()){
                mat[originales[j].i-1][originales[j].j-1] = mensaje[ori];
                ++ori;
            }
            if(g1 < mensaje.size()){
                mat[giro1[j].i-1][giro1[j].j-1] = mensaje[g1];
                ++g1;
            }
            if(g2 < mensaje.size()){
                mat[giro2[j].i-1][giro2[j].j-1] = mensaje[g2];
                ++g2;
            }
            if(g3 < mensaje.size()){
                mat[giro3[j].i-1][giro3[j].j-1] = mensaje[g3];
                ++g3;
            }
        }
        for(int i = 0; i < n;++i){
            for(int j = 0; j < n; ++j){
                cout << mat[i][j];
            }
        }
    }
    cout << '"' << endl;
}

void Rejilla::decodificar_rejilla(const string& mensaje) const{
    int tamano_bloque = n*n;
    int nbloques = int(mensaje.size() / tamano_bloque);
    if(int(mensaje.size() % tamano_bloque) != 0)  ++nbloques;
    int i_mensaje = 0;
    cout << '"';
    
    for(int z = 0; z < nbloques; ++z) {
        vector<vector<char> > mat(n,vector<char>(n,' '));
        for(int i = 0; i < n; ++i) {
            for(int j = 0; j < n; ++j) {
                mat[i][j] = mensaje[i_mensaje];
                ++i_mensaje;
            }
        }
        for(int i = 0; i < k; ++i) cout << mat[originales[i].i-1][originales[i].j-1];
        
        for(int i = 0; i < k; ++i) cout << mat[giro1[i].i-1][giro1[i].j-1];
            
        for(int i = 0; i < k; ++i) cout << mat[giro2[i].i-1][giro2[i].j-1];
            
        for(int i = 0; i < k; ++i) cout << mat[giro3[i].i-1][giro3[i].j-1];
    }
    cout << '"' << endl;
}

bool Rejilla::generar_girs(int& i, vector<vector<bool> > &matriu){
    
    giro1[i].i = n+1-originales[i].j;
    giro1[i].j = originales[i].i;
    if(matriu[giro1[i].i-1][giro1[i].j-1]) return false;
    else matriu[giro1[i].i-1][giro1[i].j-1] = true;
    
    giro2[i].i = n+1-giro1[i].j;
    giro2[i].j = giro1[i].i;
    if(matriu[giro2[i].i-1][giro2[i].j-1]) return false;
    else matriu[giro2[i].i-1][giro2[i].j-1] = true;

    giro3[i].i = n+1-giro2[i].j;
    giro3[i].j = giro2[i].i;
    if(matriu[giro3[i].i-1][giro3[i].j-1]) return false;
    else matriu[giro3[i].i-1][giro3[i].j-1] = true;

    return true;
}

bool Rejilla::es_valida() const{
    return valida;
}

void Rejilla::leer_huecos() {

    vector<vector<bool> > matriu(n,vector<bool>(n,false));
    originales = vector<Hueco>(k);
    giro1 = vector<Hueco>(k);
    giro2 = vector<Hueco>(k);
    giro3 = vector<Hueco>(k);
    valida = true;
    
    for(int i = 0; i < k; ++i) {
        Hueco x;
        cin >> x.i >> x.j;
        originales[i] = x;
        if(valida){
            if(matriu[x.i-1][x.j-1]) valida = false;
            else matriu[x.i-1][x.j-1] = true;
            valida = generar_girs(i,matriu);
        }
    }
    if(valida){
        sort(originales.begin(),originales.end(),comp);
        sort(giro1.begin(),giro1.end(),comp);
        sort(giro2.begin(),giro2.end(),comp);
        sort(giro3.begin(),giro3.end(),comp);
    }
}

bool Rejilla::consistent() const{
    if((4*k) != ((n*n)))  return false;
    else return true;
}

int Rejilla::consultar_idr() const {
    return idr;
}

void Rejilla::escribir() const {
    
    for(int i = 0; i < k; ++i) {
        cout <<"(" <<  originales[i].i << "," << originales[i].j << ")";
        if(i == k-1) cout << endl;
        else cout << " ";
    }
    
    for(int i = 0; i < k; ++i) {
        cout <<"(" <<  giro1[i].i << "," << giro1[i].j << ")";
        if(i == k-1) cout << endl;
        else cout << " ";
    }
    
    for(int i = 0; i < k; ++i) {
        cout <<"(" <<  giro2[i].i << "," << giro2[i].j << ")";
        if(i == k-1) cout << endl;
        else cout << " ";
    }
    
    for(int i = 0; i < k; ++i) {
        cout <<"(" <<  giro3[i].i << "," << giro3[i].j << ")";
        if(i == k-1) cout << endl;
        else cout << " ";
    }
}
       


