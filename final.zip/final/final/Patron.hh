/** @file Patron.hh
 @brief Especificacion de la clase Patron
 */

#ifndef _PATRON_HH
#define _PATRON_HH

#include "BinTree.hh"
#include "Conjunto_mensajes.hh"

#ifndef NO_DIAGRAM
#include <iostream>
using namespace std;
#endif

/**
    Clase Patron
 
 */

/** @class Patron
    @brief Representa un patron en un BinTree
 */

class Patron {
private:
    /**@brief Patron representado con un BinTree de enteros*/
    BinTree<int> pat;
    
    /**@brief Tamaño del bloque*/
    int b;
    
    /**@brief Operación de lectura de un patron BinTree
     \pre <em><Cierto</em>
     \post El resultado es un patron BinTree leido en preorden
     */
    static void leer_BinTree(BinTree<int> &a);
    
    /**@brief Operación de escritura de un patron BinTree en preorden
     \pre <em><Cierto</em>
     \post El resultado es un patron BinTree escrito en preorden
     */
    static void escribir_BinTree(const BinTree<int> &a);
    
    /**@brief Codigo que suma o resta dependiendio si estamos codificando o decodificando
     \pre <em><Cierto</em>
     \post El resultado es el mensaje encriptado medinate suma o resta
     */
    void sumar_restar(const BinTree<char> &arbol_mensaje, const BinTree<int> &p,string& res, int i, int fin, bool suma) const;

    /**@brief Genera un arbol BinTree de chars con el mensaje y el tamaño del bloque
     \pre <em><Cierto</em>
     \post El resultado es un arbol BinTree de chars con tamaño del bloque
     */
    void crear_arbol_mediante_mensaje(BinTree<char> &arbol_mensaje, int i, int fin, int despl, const string& mensaje) const;
    
public:
    
    //Construcotores
    
    /** @brief Constructora por defecto
     \pre <em>Cierto</em>
     \post El resultado es un patron vacio
     */
    Patron();
    
    //Destrucotores
    
    /**@brief Destructora por defecto
     \pre <em>Cierto</em>
     \post Destruye el objeto patron
     */
    ~Patron();
    
    //Modificadores
    
    /**@brief Codificadora de un mensaje no encriptado
     \pre <em><Cierto</em>
     \post El resultado es el mensaje encriptado
     */
    string codificar(int b, const string& mensaje) const;
    
    /**@brief Decodificadora de un mensaje encriptado
     \pre <em><Cierto</em>
     \post El resultado es el mensaje decodificado
     */
    string decodificar(const string& mensaje, int b) const;
    
    //Lectura y escritura
    
    /** @brief Operación de lectura de un patron en preorden
     \pre <em>Cierto</em>
     \post El parametro implicito tiene los atributos leidos por el canal estandard d'entrada
     */
    void leer_preorden();
    
    /** @brief Operación de escritura de un conjunto de patrones
     \pre <em>Cierto</em>
     \post Se han escrito por el canal estandard de salida los patrones en orden creciente de identificador
     */
    void escribir_preorden() const;

};
    
#endif


