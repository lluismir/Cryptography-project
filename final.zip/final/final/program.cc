/** @mainpage Practica pro2 Lluis Mir*/

/** @file program.cc
 @brief Programa principal que gestiona todos los comando para poder hacer las funciones de todas las clases
 */

#include <iostream>
#include <string>
#include "Conjunto_rej.hh"
#include "Conjunto_patrones.hh"
#include "Conjunto_mensajes.hh"

using namespace std;

int main() {
    int M, R, P, n, k ,b, idr, idp, error, error2;
    
    string mensaje, idm, trash;
    string comando = "";

    cin >> M;
    Conjunto_mensajes cjt_men;
    cjt_men.anadir_mensaje_inicial(M);
    
    cin >> R;
    Conjunto_rej cjt_rej;
    cjt_rej.anadir_rejilla_inicial(R);
    
    cin >>  P;
    Conjunto_patrones cjt_pat;
    cjt_pat.anadir_patron_inicial(P);

    cin >> comando;
    while (comando != "fin") {
        
        if(comando == "nuevo_mensaje" or comando == "nm") {
            cin >> idm;
            getline(cin,trash);
            getline(cin,mensaje);
            cout << '#' << comando << " " << idm << endl;
            error = cjt_men.existe_mensaje(idm);
            if(error == 0) cout << "error: ya existe un mensaje con ese identificador" << endl;
            else{
            cjt_men.nuevo_mensaje(idm, mensaje);
            cout << cjt_men.consultar_numero_mensajes() << endl;
            }
        }
        
        else if (comando == "nueva_rejilla" or comando == "nr") {
            cin >> n >> k;
            error = cjt_rej.nueva_rejilla(n,k);
            cout << '#' << comando << endl;
            if(error == -1) cout << "error: dimensiones incorrectas de la rejilla" << endl;
            else if(error == -2) cout <<"error: la rejilla con sus giros no cubre todas las posiciones N x N" << endl;
            else {
            cout << cjt_rej.consultar_numero_rejillas() << endl;
            }
        }
        
        else if (comando == "nuevo_patron" or comando == "np") {
            cout << '#' << comando << endl;
            cjt_pat.anadir_patron();
            cout << cjt_pat.consultar_numero_patrones() << endl;
        }
        
        else if (comando == "borra_mensaje" or comando == "bm") {
            cin >> idm;
            cout << '#' << comando << ' ' << idm << endl;
            error = cjt_men.existe_mensaje(idm);
            if(error == -1) cout << "error: el mensaje no existe"<< endl;
            else {
                cjt_men.borrar_mensaje(idm);
                cout << cjt_men.consultar_numero_mensajes() << endl;
            }
        }
        
        else if (comando == "listar_mensajes" or comando == "lm") {
            cout << '#' << comando << endl;
            cjt_men.listar_mensajes();
        }
        
        else if (comando == "listar_rejillas" or comando == "lr") {
            cout << '#' << comando << endl;
            cjt_rej.listar_rejillas();
        }
        
        else if (comando == "listar_patrones" or comando == "lp") {
            cout << '#' << comando << endl;
            cjt_pat.listar_patrones();
        }
        
        else if (comando == "codificar_rejilla" or comando == "cr") {
            cin >> idr;
            getline(cin,trash);
            getline(cin,mensaje);
            cout << '#' << comando << " " << idr << endl;
            error = cjt_rej.existe_rejilla(idr);
            
            if(error == -1) cout << "error: la rejilla no existe"<< endl;
            else {
                cjt_rej.consultar_rejilla(idr).codificar_rejilla(mensaje);
            }
        }
        
        else if(comando == "codificar_guardado_rejilla" or comando == "cgr") {
            cin >> idm >> idr;
            error = cjt_men.existe_mensaje(idm);
            error2 = cjt_rej.existe_rejilla(idr);
            cout << '#' << comando << " " << idm << " " << idr << endl;
            if (error == -1) cout << "error: el mensaje no existe" << endl;
            else if(error2 == -1) cout << "error: la rejilla no existe" << endl;
            else {
                cjt_rej.consultar_rejilla(idr).codificar_rejilla(cjt_men.consultar_mensaje(idm));
            }
        }
        
        else if (comando == "decodificar_rejilla" or comando == "dr") {
            cin >> idr;
            getline(cin,trash);
            getline(cin,mensaje);
            cout << '#' << comando << " " << idr << endl;
            error = cjt_rej.existe_rejilla(idr);
            if(error == -1) cout << "error: la rejilla no existe" << endl;
            else{
                int n = cjt_rej.consultar_n_amb_idr(idr);
                error2 = cjt_men.mensaje_valido(mensaje, n);
                if(error2 == -1) cout << "error: la dimension del mensaje es inadecuada para la rejilla" << endl;
                else {
                    cjt_rej.consultar_rejilla(idr).decodificar_rejilla(mensaje);
                }
            }
        }
        
        else if (comando == "codificar_patron" or comando == "cp") {
            cin >> idp >> b;
            getline(cin, trash);
            getline(cin,mensaje);
            cout << '#' << comando << " " << idp << " " << b << endl;
            error = cjt_pat.existe_patron(idp);
            if(error == -1) cout << "error: el patron no existe" << endl;
            else cout << '"' << cjt_pat.codificar_patron(idp, b, mensaje) << '"' << endl;
        }
        
        else if (comando == "codificar_guardado_patron" or comando == "cgp") {
            cin >> idm >> idp >> b;
            error = cjt_men.existe_mensaje(idm);
            error2 = cjt_pat.existe_patron(idp);
            cout << '#' << comando << " " << idm << " " << idp << " " << b << endl;
            if(error == -1) cout << "error: el mensaje no existe" << endl;
            else if(error2 == -1) cout << "error: el patron no existe" << endl;
            else {
                string x = cjt_men.consultar_mensaje(idm);
                cout << '"' <<  cjt_pat.codificar_patron(idp, b, x) << '"' << endl;
            }
        }

        else if (comando == "decodificar_patron" or comando == "dp") {
            cin >> idp >> b;
            cout << '#' << comando << " " << idp << " " << b << endl;
            error = cjt_pat.existe_patron(idp);
            if(error == -1) cout << "error: el patron no existe" << endl;
            else {
                getline(cin, trash);
                getline(cin,mensaje);
                cjt_men.nuevo_mensaje(idm, mensaje);
                cout << '"' << cjt_pat.decodificar_patron(idp, b, mensaje) << '"' << endl;
            }
        }
        cin >> comando;
    }
}


