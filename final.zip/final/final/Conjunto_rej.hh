/** @file Conjunto_rej.hh
    @brief Especificación de la clase Conjunto_rej
 */

#ifndef _CONJUNTO_REJ_HH
#define _CONJUNTO_REJ_HH

#include "Rejilla.hh"

#ifndef NO_DIAGRAM
#include <iostream>
#include <vector>
using namespace std;
#endif


/**
    Clase Conjunto rejillas
*/

/** @class Conjunto_rej
    @brief Respresenta un conjunto de Rejillas en un vector
 */

class Conjunto_rej {
private:
    
    /**@brief Vector de rejillas que representa el conjunto*/
    vector<Rejilla> cjt_rej;
    
public:
    
    //Contructoras
    
    /**@brief Constructora por defecto
     \pre <em><Cierto</em>
     \post El resultado es un conjunto de  rejillas vacias
     */
    Conjunto_rej();
    
    //Destrucotoras
    
    /** @brief Destructora por defecto
     \pre <em>Cierto</em>
     \post Destruye un conjunto de rejillas
     */
    ~Conjunto_rej();
    
    //Modificadoras
    
    /**@brief Añade una rejilla al conjunto si cumple los requisitos
     \pre <em><Cierto</em>
     \post El resultado es una rejilla valida guardada, en el caso que no sea valida o repetida no se guardara
     */
    int nueva_rejilla(int& n, int& k);
    
    /**@brief Inicializa la rejilla
     \pre La rejilla no existe en el conjunto
     \post El resultado es una secuencia de R rejillas validas guardadas en orden del identificador
     */
    void anadir_rejilla_inicial(int& R);
    
    //Consultoras
    
    /**@brief Consultora que nos devuelve una rejilla
     \pre <em>Cierto</em>
     \post El resultado es una rejilla con el identificador que hemos pasado por referencia
     */
    Rejilla consultar_rejilla(const int& idr) const;
    
   /** @brief Consultora del numero de rejillas del conjunto
     \pre <em><Cierto</em>
     \post Nos devuelve el numero de rejillas que tenemos en el conjunto
     */
    int consultar_numero_rejillas() const;
  
    /**@brief Consultora que nos devuelve las rejillas
     \pre El parámetro implícito está inicializado
     \post El resultado són todas las rejillas que contenia el p.i. en orden alfabetico de identificador
     */
    void listar_rejillas() const;
    
    /**@brief Consultora que nos dice si un mensaje ya existia
     \pre El parámetro implícito está inicializado
     \post Devolvera -1 si  no existe en el conjunto
     */
    int existe_rejilla(int& idr) const;
    
    /** @brief Consultora del tamaño de la rejilla mediante el identificador
      \pre <em><Cierto</em>
      \post Nos devuelve el tamaño de la rejilla
      */
    int consultar_n_amb_idr(const int& idr) const;
       
};

#endif


