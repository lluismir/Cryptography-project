#include <iostream>
#include "Conjunto_patrones.hh"

using namespace std;


Conjunto_patrones::Conjunto_patrones(){
    
}
Conjunto_patrones::~Conjunto_patrones(){
    
}

string Conjunto_patrones::decodificar_patron(int idp, int b, const string& mensaje) const {
    return cjt_pat[idp-1].decodificar(mensaje, b);
}

string Conjunto_patrones::codificar_patron(int idp, int b, const string& mensaje) const{
    return cjt_pat[idp-1].codificar(b, mensaje);
}

void Conjunto_patrones::anadir_patron() {
    Patron pat;
    pat.leer_preorden();
    cjt_pat.push_back(pat);
}

void Conjunto_patrones::anadir_patron_inicial(int P) {
    for(int i = 0; i < P; ++i) anadir_patron();
}

void Conjunto_patrones::listar_patrones() const{
    for(int i = 0; i < cjt_pat.size(); ++i){
        cout << "Patron " << i+1 << ":" << endl;
        cjt_pat[i].escribir_preorden();
    }
}

int Conjunto_patrones::consultar_numero_patrones() const{
    return int(cjt_pat.size());
}

int Conjunto_patrones::existe_patron(int idp) const {
    if(idp >= 1 and idp <= cjt_pat.size()) return 0;
    return -1;
}





