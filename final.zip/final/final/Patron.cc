#include <iostream>
#include "Patron.hh"

using namespace std;

Patron::Patron(){
    
}

Patron::~Patron(){
    
}
void Patron::crear_arbol_mediante_mensaje(BinTree<char> &arbol_mensaje, int i, int fin, int despl, const string& mensaje) const{
    if(fin >= i){
        char base = mensaje[despl+i];
        BinTree<char> der, izq;
        crear_arbol_mediante_mensaje(izq, 2*i+1, fin, despl, mensaje);
        crear_arbol_mediante_mensaje(der, 2*i+2,fin, despl, mensaje);
        arbol_mensaje = BinTree<char>(base,izq, der);
    }
}
  
string Patron::codificar(int b, const string& mensaje) const{
    int tamany = int(mensaje.size()/b);
    string mensaje_final;
    
    for(int i = 0; i < tamany; ++i) {
        string bloque;
        bloque.resize(b);
        int despl = i*b;
        int ini = 0;
        int fin = b-1;
        BinTree<char> arbol_mensaje;
        crear_arbol_mediante_mensaje(arbol_mensaje, ini, fin, despl, mensaje);
        sumar_restar(arbol_mensaje, pat, bloque, ini, fin, true);
        mensaje_final += bloque;
    }
    
    if(mensaje.size()%b != 0){
        int residu = mensaje.size()%b;
        string bloque;
        bloque.resize(residu);
        int despl = tamany*b;
        int ini = 0;
        int fin = residu-1;
        BinTree<char> arbol_mensaje;
        crear_arbol_mediante_mensaje(arbol_mensaje, ini, fin, despl, mensaje);
        sumar_restar(arbol_mensaje, pat, bloque, ini, fin, true);
        mensaje_final += bloque;
    }
    return mensaje_final;
}

void Patron::sumar_restar(const BinTree<char> &arbol_mensaje, const BinTree<int> &p,string& res, int i, int fin, bool suma) const{
    if(not arbol_mensaje.empty()){
        if(not p.empty()){
            char c;
            if(suma) c = 32 + (arbol_mensaje.value() + p.value() - 32) % 95;
            else c = 32 + ((arbol_mensaje.value() - p.value() - 32) % 95 + 95) % 95;
            res[i] = c;
            sumar_restar(arbol_mensaje.left(), p.left(), res, 2*i+1, fin, suma);
            sumar_restar(arbol_mensaje.right(), p.right(), res, 2*i+2, fin, suma);
        }
        else{
            sumar_restar(arbol_mensaje, pat, res, i, fin, suma);
        }
    }
}

string Patron::decodificar(const string &mensaje, int b) const{
    int tamany = int(mensaje.size()/b);
    string mensaje_final;
    
    for(int i = 0; i < tamany; ++i) {
        string bloque;
        bloque.resize(b);
        int despl = i*b;
        int ini = 0;
        int fin = b-1;
        BinTree<char> arbol_mensaje;
        crear_arbol_mediante_mensaje(arbol_mensaje, ini, fin, despl, mensaje);
        sumar_restar(arbol_mensaje, pat, bloque, ini, fin, false);
        mensaje_final += bloque;
    
    }
    if(mensaje.size()%b != 0){
        int residu = mensaje.size()%b;
        string bloque;
        bloque.resize(residu);
        int despl = tamany*b;
        int ini = 0;
        int fin = residu-1;
        BinTree<char> arbol_mensaje;
        crear_arbol_mediante_mensaje(arbol_mensaje, ini, fin, despl, mensaje);
        sumar_restar(arbol_mensaje, pat, bloque, ini, fin, false);
        mensaje_final += bloque;
    }
    return mensaje_final;
}

void Patron::leer_BinTree(BinTree<int> &pat){
    int x;
    cin >> x;
    if(x != -1) {
        BinTree<int> e,d;
        leer_BinTree(e);
        leer_BinTree(d);
        pat = BinTree<int>(x,e,d);
    }
}

void Patron::leer_preorden() {
    leer_BinTree(pat);
}

void Patron::escribir_BinTree(const BinTree<int> &pat) {
    if(pat.empty()) cout << "()";
    else {
        cout << '(';
        cout << pat.value();
        escribir_BinTree(pat.left());
        escribir_BinTree(pat.right());
        cout << ')';
    }
}

void Patron::escribir_preorden() const{
    escribir_BinTree(pat);
    cout << endl;
}


