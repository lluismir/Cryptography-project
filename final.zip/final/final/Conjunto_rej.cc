#include <iostream>
#include "Conjunto_rej.hh"

using namespace std;


Conjunto_rej::Conjunto_rej() {
    
}


Conjunto_rej::~Conjunto_rej() {
    
}

int Conjunto_rej::nueva_rejilla(int& n, int& k) {
    Rejilla rej(n,k,int(cjt_rej.size())+1);
    rej.leer_huecos();
    if(not rej.consistent()) return -1;
    if(not rej.es_valida()) return -2;
    cjt_rej.push_back(rej);
    return 0;
}

void Conjunto_rej::anadir_rejilla_inicial(int& R) {
    int n, k;
    for(int i = 0; i < R; ++i) {
        cin >> n >> k;
        nueva_rejilla(n,k);
    }
}

int  Conjunto_rej::consultar_numero_rejillas() const {
    return int(cjt_rej.size());
}

int Conjunto_rej::existe_rejilla(int& idr) const {
    for(int i = 0; i < cjt_rej.size(); ++i) {
        if(cjt_rej[i].consultar_idr() == idr) return 0;
    }
    return -1;
}

void Conjunto_rej::listar_rejillas() const {
    for(int i = 0; i < cjt_rej.size(); ++i) {
        cout << "Rejilla " << i+1 << ":" << endl;
        cout << cjt_rej[i].consultar_n() << " " <<  cjt_rej[i].consultar_k() << endl;
        cjt_rej[i].escribir();
    }
}

Rejilla Conjunto_rej::consultar_rejilla(const int& idr) const{
    return cjt_rej[idr-1];
}

int Conjunto_rej::consultar_n_amb_idr(const int& idr) const{
    return cjt_rej[idr-1].consultar_n();
}


