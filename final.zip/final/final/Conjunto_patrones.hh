/** @file Conjunto_patrones.hh
 @brief Especificación de la clase Conjunto_patrones
 */

#ifndef _CONJUNTO_PATRONES_HH
#define _CONJUNTO_PATRONES_HH

#include "Patron.hh"

#ifndef NO_DIAGRAM
#include <iostream>
#include <vector>
using namespace std;
#endif


/**
    Clase Conjunto patrones
 
 */

/** @class Conjunto_patrones
    @brief Representa un conjunto de Patrones en un vector
 */

class Conjunto_patrones {
private:
    
    /** @brief Vector de patrones que representa el conjunto*/
    vector <Patron> cjt_pat;
    
public:
    
    //Construcotores
    
    /**@brief Constructora por defecto
     \pre <em>Cierto</em>
     \post El resultado es un conjunto de patrones vacio
     */
    Conjunto_patrones();
    
    //Destrucotores
    
    /**@brief Destructora por defecto
     \pre <em>Cierto</em>
     \post Destruye el objeto Conjunto de patrones
     */
    ~Conjunto_patrones();
    
    //Modificadores
    
    /** @brief Decodifica un mensaje en un arbol
     \pre <em>Cierto</em>
     \post El resulado es el mensaje decodificado
     */
    string decodificar_patron(int idp, int b, const string& mensaje) const;
    
    /**@brief Codifica un mensaje en un arbol
     \pre <em><Cierto</em>
     \post El resultado es  un mensaje codificado en un arbol
     */
    
    string codificar_patron(int idp, int b, const string& mensaje) const;
    
    /** @brief Añade un patron en el conjunto de patrones
     \pre <em><Cierto</em>
     \post El resultado es un patron en el conjunto
     */
    void anadir_patron();
    
    /** @brief Inicializa el conjunto
     \pre El parámetro implícito no está inicializado,
     \post El resultado es una secuencia de P patrones guardados
     */
    void anadir_patron_inicial(int P);
    
    //Consultores
    
    /**@brief Consultora de los patrones
     \pre  <em>Cierto</em>
     \post El resultado són todos los patrones que contenia el parametro implícito
     */
    void listar_patrones() const;
    
    /**@brief Consultora del número de patrones
     \pre  <em>Cierto</em>
     \post El resultado es el número de patrones del parametro implícito
     */
    int consultar_numero_patrones() const;
    
    /**@brief Consultora de un patron
     \pre  <em>Cierto</em>
     \post El resultado es -1 si no existe el patron
     */
    int existe_patron(int idp) const;
    
};

#endif

