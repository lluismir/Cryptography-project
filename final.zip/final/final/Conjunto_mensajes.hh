/** @file Conjunto_mensajes.hh
 @brief Especificación de la clase Conjunto_mensajes
 */

#ifndef _CONJUNTO_MENSAJES_HH
#define _CONJUNTO_MENSAJES_HH

#ifndef NO_DIAGRAM
#include <iostream>
#include <string>
#include <map>
using namespace std;
#endif


/**
    Clase Conjunto mensajes
 
 */

/** @class Conjunto_mensajes
    @brief Representa un conjunto de mensajes
 */

class Conjunto_mensajes {
private:
    /**@brief Map formado por dos strings que representan el conjunto*/
    map<string,string> cjt_men;
    
public:
    
    //Construcotores
    
    /**@brief Constructora por defecto
     \pre <em>Cierto</em>
     \post El resultado es un conjunto de mensajes vacio
     */
    Conjunto_mensajes();
    
    //Destrucotores
    
    /**@brief Destructora por defecto
     \pre <em>Cierto</em>
     \post Destruye el objeto conjunto de mensajes
     */
    ~Conjunto_mensajes();
    
    //Modificadora
    
    /** @brief Añade un mensaje
     \pre El mensaje no existe en el conjunto de mensajes
     \post El resultado es un mensaje nuevo en el map con identificador y el mensaje
     */
    void nuevo_mensaje(string& idm, string& mensaje);
    
    /**@brief Inicializa el conjunto
     \pre  El mensaje no existe en el conjunto de mensajes
     \post El resultado es una secuencia de M mensajes guardados
     */
    void anadir_mensaje_inicial(int& M);
    
    /** @brief Elimina un mensaje
     \pre <em>Cierto</em>
     \post El resultado es un mensaje eliminado del map
     */
    void borrar_mensaje(string& idm);
    
    //Consultora
    
    /**@brief Consultora de un mensaje valido para decodificar
     \pre <em>Cierto</em>
     \post El resultado nos devolvera -1 si no es valido
     */
    int mensaje_valido(string& mensaje, int& n) const;
    
    /** @brief Consultora que nos listara los mensajes del conjunto en orden alfabetico del identificador
     \pre <em>Cierto</em>
     \post El resultado són todos los mensajes mostrados por orden alfabetico del identificador del mensaje
     */
    void listar_mensajes() const;
    
    /**@brief Consultora que nos indica el número de mensajes
     \pre <em>Cierto</em>
     \post El resultado són todos los mensajes que contenia el p.i. en orden alfabetico de identificador
     */
    int consultar_numero_mensajes() const;
  
    /**@brief Consultora del mensaje mediante el identificador del mensaje
     \pre <em>Cierto</em>
     \post El resultado es un mensaje del p.i. con el identificador idm
     */
    string consultar_mensaje(string &idm) const;
    
    /**@brief Consultora que nos dice si un mensaje existe
     \pre  <em>Cierto</em>
     \post El resultado sera -1 si el mensaje no existe en el conjunto
     */
    int existe_mensaje(string& idm) const;

};

#endif
