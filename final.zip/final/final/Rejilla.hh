/** @file Rejilla.hh
    @brief Especificación de la clase Rejilla
 */

#ifndef _REJILLA_HH
#define _REJILLA_HH

#include "Conjunto_mensajes.hh"

#ifndef NO_DIAGRAM
#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
using namespace std;
#endif

/**
    Clase Rejilla
*/

/** @class Rejilla
    @brief Respresenta una rejilla, mediante el uso de vectores
 
 */

class Rejilla {
    
private:
    /**@brief Identificador de la rejilla*/
    int idr;
    
    /**@brief Tamaño de la matriz*/
    int n;
    
    /**@brief Número de huecos de la rejilla*/
    int k;
    
    /**@brief Indica la validez de la rejilla*/
    bool valida;

    /**@brief Representa los huecos mediante un struct qur contiene dos variables i y j para cada una de las coordenadas*/
    struct Hueco{
        int i, j;
    };
    
    /**@brief Vector que contiene los huecos originales*/
    vector<Hueco> originales;
    
    /**@brief Vector que contiene los huecos girados una vez*/
    vector<Hueco> giro1;
    
    /**@brief Vector que contiene los huecos girados dos veces*/
    vector<Hueco> giro2;

    /**@brief Vector que contiene los huecos girados tres veces*/
    vector<Hueco> giro3;
        
    /**@brief Ordena los huecos en orden creciente
     \pre <em>Cierto</em>
     \post El resultado es el vector ordenado en orden creciente
     */
    static bool comp(const Hueco& h1, const Hueco& h2);
    
    /**@brief Gira los huecos 90 grados y verifica su validez
     \pre El parametro vector es valido y esta inicializado
     \post Guardara los nuevos giros en el vector correspondiente segun el número de giro que sea
     */
    bool generar_girs(int& i, vector<vector<bool> > &matriu);
    
public:
    
    //Contructoras
    
    /**@brief Constructora por defecto
     \pre <em>Cierto</em>
     \post El resultado es una rejilla no inicializada
     */
    Rejilla();
    
    /**@brief Constructora con atributos
     \pre Cumple la condicion de rejilla valida
     \post El resultado es una rejilla de n por n con k huecos y su identificador
     */
    Rejilla(int n, int k,int idr);
    
    //Destructoras
    
    /**@brief Destructora por defecto
     \pre <em>Cierto</em>
     \post Destruye un objeto rejilla
     */
    ~Rejilla();
    
    //Modificadora
    
    /**@brief Codifica el mensaje en una rejilla
     \pre <em>Cierto</em>
     \post El resultado es el mensaje codificado
     */
    void codificar_rejilla(const string& mensaje) const;
    
    /**@brief Decodificadora de un mensaje mediante una rejilla
     \pre <em>Cierto</em>
     \post El resultado es un mensaje decodificado
     */
    void decodificar_rejilla(const string& mensaje) const;
   
    //Consultoras
    
    /**@brief Consultora del identificador de una matriz
     \pre <em>Cierto</em>
     \post El resultado es el identificador de la rejilla
     */
    int consultar_idr() const;
    
    /**@brief Consultora del numero de huecos de una matriz
     \pre <em>Cierto</em>
     \post El resultado es el entero k de la rejilla
     */
    int consultar_k() const;
    
    /**@brief Consultora de la longitud de la rejilla
     \pre <em>Cierto</em>
     \post El resultado es el entero n de la rejilla
     */
    int consultar_n() const;

    /**@brief Consultora de la validez de un hueco
     \pre El parámetro implícito está inicializado
     \post El resultado nos indicara si es valido el hueco
     */
    bool hueco_valido() const;
    
    /**@brief Consultora que nos indica si la rejilla es consistente
     \pre <em>Cierto</em>
     \post El resultado nos devuelve un boleano dependiende de si la rejilla es consistente o no
     */
    bool consistent() const;
    
    /**@brief Consultora que indica si la rejilla es valida
     \pre <em>Cierto</em>
     \post El resultado nos devolvera un boleano segun la validez de la rejilla
     */
    bool es_valida() const;
    
    //Lectura y escritura
    
    /** @brief Operación de escritura de una rejila
     \pre <em>Cierto</em>
     \post Se han escrito por el canal estandard de salida la rejilla en orden creciente de identifcador de la rejilla
     */
    void escribir() const;
    
    /**@brief Operación de lectura y verificacion de los huecos
     \pre El parámetro implicto está incializado
     \post El resultado son 4 vectores con todos los giros ordenados de forma creciente en el caso que sean validos, en caso contrario estaran vacios
     */
    void leer_huecos();

};

#endif
