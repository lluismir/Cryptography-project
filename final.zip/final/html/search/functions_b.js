var searchData=
[
  ['rejilla_0',['Rejilla',['../class_rejilla.html#a0d4c2d54277ee3862d53d0f673ac8783',1,'Rejilla::Rejilla()'],['../class_rejilla.html#a71777a7999e48d266ee3cf44a03d6603',1,'Rejilla::Rejilla(int n, int k, int idr)']]]
];
