var searchData=
[
  ['n_0',['n',['../class_rejilla.html#ab0b9df8a469bd69c07d1786082d1a438',1,'Rejilla']]],
  ['nueva_5frejilla_1',['nueva_rejilla',['../class_conjunto__rej.html#add3099aaa8142c0f332e22a6f345b340',1,'Conjunto_rej']]],
  ['nuevo_5fmensaje_2',['nuevo_mensaje',['../class_conjunto__mensajes.html#a43048fc280e121a0b494238caeb8747f',1,'Conjunto_mensajes']]]
];
