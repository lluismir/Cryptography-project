var searchData=
[
  ['pat_0',['pat',['../class_patron.html#ae7c7a365483271319377798492c0d554',1,'Patron']]]
];
