var searchData=
[
  ['conjunto_5fmensajes_0',['Conjunto_mensajes',['../class_conjunto__mensajes.html',1,'']]],
  ['conjunto_5fpatrones_1',['Conjunto_patrones',['../class_conjunto__patrones.html',1,'']]],
  ['conjunto_5frej_2',['Conjunto_rej',['../class_conjunto__rej.html',1,'']]]
];
