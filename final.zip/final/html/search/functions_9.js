var searchData=
[
  ['nueva_5frejilla_0',['nueva_rejilla',['../class_conjunto__rej.html#add3099aaa8142c0f332e22a6f345b340',1,'Conjunto_rej']]],
  ['nuevo_5fmensaje_1',['nuevo_mensaje',['../class_conjunto__mensajes.html#a43048fc280e121a0b494238caeb8747f',1,'Conjunto_mensajes']]]
];
