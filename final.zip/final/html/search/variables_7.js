var searchData=
[
  ['originales_0',['originales',['../class_rejilla.html#a499fa6afb55fe22b8108336073981ebf',1,'Rejilla']]]
];
