var searchData=
[
  ['anadir_5fmensaje_5finicial_0',['anadir_mensaje_inicial',['../class_conjunto__mensajes.html#adef63718a571f9b8c34e4bd4d7e3a5dd',1,'Conjunto_mensajes']]],
  ['anadir_5fpatron_1',['anadir_patron',['../class_conjunto__patrones.html#a73d72ec7ac83968bff2929991249d46b',1,'Conjunto_patrones']]],
  ['anadir_5fpatron_5finicial_2',['anadir_patron_inicial',['../class_conjunto__patrones.html#a7e0986f5d91c7811668f2ee117144baa',1,'Conjunto_patrones']]],
  ['anadir_5frejilla_5finicial_3',['anadir_rejilla_inicial',['../class_conjunto__rej.html#a5869019f2d8aed030d563bf164fc508d',1,'Conjunto_rej']]]
];
