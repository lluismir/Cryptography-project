var searchData=
[
  ['valida_0',['valida',['../class_rejilla.html#a7ca7a148052f563d398bf7d4147ca30d',1,'Rejilla']]]
];
