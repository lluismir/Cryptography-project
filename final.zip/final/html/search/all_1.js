var searchData=
[
  ['b_0',['b',['../class_patron.html#a107898743e635a2162721a74083f7313',1,'Patron']]],
  ['borrar_5fmensaje_1',['borrar_mensaje',['../class_conjunto__mensajes.html#a3e8659e34d1b7e9cdc00c58af1a9f1f6',1,'Conjunto_mensajes']]]
];
