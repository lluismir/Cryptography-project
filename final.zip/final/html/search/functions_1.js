var searchData=
[
  ['borrar_5fmensaje_0',['borrar_mensaje',['../class_conjunto__mensajes.html#a3e8659e34d1b7e9cdc00c58af1a9f1f6',1,'Conjunto_mensajes']]]
];
