var searchData=
[
  ['main_0',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['mensaje_5fvalido_1',['mensaje_valido',['../class_conjunto__mensajes.html#a6b01c1dc684a504d8dd7fa46a2ff98b7',1,'Conjunto_mensajes']]]
];
