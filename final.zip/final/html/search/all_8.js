var searchData=
[
  ['j_0',['j',['../struct_rejilla_1_1_hueco.html#a901fe6613a847e398d6641c23b456679',1,'Rejilla::Hueco']]]
];
