var searchData=
[
  ['i_0',['i',['../struct_rejilla_1_1_hueco.html#a95d1215028c3434d9a8ebe6ccc9fa51a',1,'Rejilla::Hueco']]],
  ['idr_1',['idr',['../class_rejilla.html#a922a94529cb96a9b3afe80b09db74111',1,'Rejilla']]]
];
