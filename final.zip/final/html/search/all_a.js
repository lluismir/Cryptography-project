var searchData=
[
  ['leer_5fbintree_0',['leer_BinTree',['../class_patron.html#a931016d510daa2991a5818ae632acad1',1,'Patron']]],
  ['leer_5fhuecos_1',['leer_huecos',['../class_rejilla.html#a3c953d958b14ddeb7b73710982bcfa80',1,'Rejilla']]],
  ['leer_5fpreorden_2',['leer_preorden',['../class_patron.html#a83267f94c9cb440ce748e0a13bec51be',1,'Patron']]],
  ['listar_5fmensajes_3',['listar_mensajes',['../class_conjunto__mensajes.html#a552f785ce88530acec5ebbf8e889d05b',1,'Conjunto_mensajes']]],
  ['listar_5fpatrones_4',['listar_patrones',['../class_conjunto__patrones.html#a266da836c68e95f8f39646dbbbb7231b',1,'Conjunto_patrones']]],
  ['listar_5frejillas_5',['listar_rejillas',['../class_conjunto__rej.html#ad01579573fd7d12533653d6e0a26d072',1,'Conjunto_rej']]]
];
