var searchData=
[
  ['patron_0',['Patron',['../class_patron.html',1,'']]]
];
