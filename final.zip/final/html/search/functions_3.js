var searchData=
[
  ['decodificar_0',['decodificar',['../class_patron.html#a4ebae01b990c5dc196bdbe01ba135a85',1,'Patron']]],
  ['decodificar_5fpatron_1',['decodificar_patron',['../class_conjunto__patrones.html#a8409e1de9840d212c11d56db2772295e',1,'Conjunto_patrones']]],
  ['decodificar_5frejilla_2',['decodificar_rejilla',['../class_rejilla.html#ac678293cbded01a4db0d32c5e005c6c5',1,'Rejilla']]]
];
