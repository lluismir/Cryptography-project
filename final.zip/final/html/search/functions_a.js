var searchData=
[
  ['patron_0',['Patron',['../class_patron.html#a8664d13f6847795f5e480b758d66ff88',1,'Patron']]]
];
