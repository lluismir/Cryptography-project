var searchData=
[
  ['b_0',['b',['../class_patron.html#a107898743e635a2162721a74083f7313',1,'Patron']]]
];
