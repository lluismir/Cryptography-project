var searchData=
[
  ['sumar_5frestar_0',['sumar_restar',['../class_patron.html#a7cdf1aeb3d11576f28916d7f5f77c186',1,'Patron']]]
];
