var searchData=
[
  ['generar_5fgirs_0',['generar_girs',['../class_rejilla.html#abba8a6cf74812ce2ce0f08f0c89ed85a',1,'Rejilla']]]
];
