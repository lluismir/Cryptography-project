var searchData=
[
  ['generar_5fgirs_0',['generar_girs',['../class_rejilla.html#abba8a6cf74812ce2ce0f08f0c89ed85a',1,'Rejilla']]],
  ['giro1_1',['giro1',['../class_rejilla.html#a21dba1e1efbb5929a701295dc15a7ae2',1,'Rejilla']]],
  ['giro2_2',['giro2',['../class_rejilla.html#a5f4a1149f2aa7c0d5dc04930d7ceaa6e',1,'Rejilla']]],
  ['giro3_3',['giro3',['../class_rejilla.html#a2fbe1e2c85eba8f54a5aaec4e549a983',1,'Rejilla']]]
];
